<template>
    <el-menu-item index="1"><router-link class="link" to="/Home">Home page</router-link></el-menu-item>
</template>
